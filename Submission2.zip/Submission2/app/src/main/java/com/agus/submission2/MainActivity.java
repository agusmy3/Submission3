package com.agus.submission2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import com.agus.submission2.Adapter.UserAdapter;
import com.agus.submission2.Model.GetItemUser;
import com.agus.submission2.Rest.ApiClient;
import com.agus.submission2.Rest.ApiInterface;
import com.agus.submission2.ViewModel.MainViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class MainActivity extends AppCompatActivity {
    private MainViewModel mainViewModel;
    private ProgressBar progressBar;
    ApiInterface mApiInterface;
    List<GetItemUser> listUser = new ArrayList<>();
    UserAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).setTitle(R.string.search_activity);

        RecyclerView rvUser = findViewById(R.id.recycleView1);
        progressBar = findViewById(R.id.progresBar1);
        mainViewModel = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(MainViewModel.class);
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        adapter = new UserAdapter(listUser, MainActivity.this);
        rvUser.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        rvUser.setItemAnimator(new DefaultItemAnimator());
        rvUser.setHasFixedSize(true);
        rvUser.setAdapter(adapter);
        rvUser.invalidate();

        mainViewModel.getListUser().observe(this, new Observer<List<GetItemUser>>() {
            @Override
            public void onChanged(List<GetItemUser> userList) {
                if (userList != null && userList.size()>0) {
                    listUser.addAll(userList);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this,getString(R.string.found)+" : "+listUser.size(),Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this,getString(R.string.not_found),Toast.LENGTH_LONG).show();
                }
                showLoading(false);
            }
        });

        adapter.setOnItemClickCallback(new UserAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(GetItemUser data) {
                String username = data.getLogin();
                Intent toDetail = new Intent(MainActivity.this, DetailUserActivity.class);
                toDetail.putExtra(DetailUserActivity.EXTRA_USER, username);
                startActivity(toDetail);
            }

        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        if (searchManager != null) {
            SearchView searchView = (SearchView) (menu.findItem(R.id.search)).getActionView();
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setQueryHint(getResources().getString(R.string.search_hint));
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    showLoading(true);
                    mainViewModel.setListUser(query);
                    return true;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    listUser.clear();
                    adapter.notifyDataSetChanged();
                    return false;
                }
            });
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu1) {
            Intent mIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(mIntent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void showLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

}