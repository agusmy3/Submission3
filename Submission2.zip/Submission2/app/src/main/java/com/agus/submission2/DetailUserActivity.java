package com.agus.submission2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.agus.submission2.Adapter.SectionsPagerAdapter;
import com.agus.submission2.Model.GetSingleUser;
import com.agus.submission2.Rest.ApiClient;
import com.agus.submission2.Rest.ApiInterface;
import com.bumptech.glide.Glide;
import com.google.android.material.tabs.TabLayout;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailUserActivity extends AppCompatActivity {

    public static final String EXTRA_USER = "extra_user";
    TextView tv_nama, tv_following, tv_followers, tv_repository, tv_company, tv_location;
    ImageView img_user;
    ApiInterface mApiInterface;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_user);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(R.string.detail_activity);

        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        tv_nama = findViewById(R.id.name_user);
        tv_followers = findViewById(R.id.int_followers_user);
        tv_following = findViewById(R.id.int_following_user);
        tv_repository = findViewById(R.id.int_repository_user);
        tv_company = findViewById(R.id.company);
        tv_location = findViewById(R.id.location);
        img_user = findViewById(R.id.img_user);
        username = getIntent().getStringExtra(EXTRA_USER);

        Call<GetSingleUser> userCall = mApiInterface.getDetailUser(username);
        userCall.enqueue(new Callback<GetSingleUser>() {
            @Override
            public void onResponse(Call<GetSingleUser> call, Response<GetSingleUser> response) {
                try {
                    if (response.isSuccessful() && response.body()!=null) {
                        Toast.makeText(DetailUserActivity.this,getString(R.string.selected) +" : "+ response.body().getLogin(),Toast.LENGTH_LONG).show();
                        tv_nama.setText(response.body().getName());
                        tv_following.setText(String.valueOf(response.body().getFollowing()));
                        tv_followers.setText(String.valueOf(response.body().getFollowers()));
                        tv_repository.setText(String.valueOf(response.body().getPublicRepos()));
                        tv_company.setText(response.body().getCompany());
                        tv_location.setText(response.body().getLocation());
                        Glide.with(DetailUserActivity.this)
                                .load(response.body().getAvatarUrl())
                                .into(img_user);
                    }else{
                        Toast.makeText(DetailUserActivity.this,getString(R.string.selected_error)+" : "+response.errorBody(),Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e){
                    Log.d("Exception", e.toString());
                }

            }
            @Override
            public void onFailure(Call<GetSingleUser> call, Throwable t) {
                Log.d("onFailure", t.toString());
            }
        });

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager(), username);
        ViewPager viewPager = findViewById(R.id.view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu1) {
            Intent mIntent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
            startActivity(mIntent);
        }
        return super.onOptionsItemSelected(item);
    }

}